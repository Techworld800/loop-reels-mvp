'use client';
import { useEffect, useState } from 'react';

type State = 'loading' | 'unsupported' | 'off' | 'on' | 'denied';

function keyToBytes(b64: string) {
  const padded = (b64 + '='.repeat((4 - (b64.length % 4)) % 4)).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(padded);
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

export default function NotifyButton({ onNotice }: { onNotice: (m: string) => void }) {
  const [state, setState] = useState<State>('loading');

  useEffect(() => {
    (async () => {
      if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
        setState('unsupported');
        return;
      }
      if (Notification.permission === 'denied') {
        setState('denied');
        return;
      }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      setState(sub ? 'on' : 'off');
    })().catch(() => setState('unsupported'));
  }, []);

  async function enable() {
    try {
      const pub = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
      if (!pub) {
        onNotice('Notifications are not set up yet.');
        return;
      }
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setState(permission === 'denied' ? 'denied' : 'off');
        onNotice('Notifications were not allowed.');
        return;
      }
      const reg = await navigator.serviceWorker.ready;
      const sub =
        (await reg.pushManager.getSubscription()) ||
        (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyToBytes(pub) }));
      const res = await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(sub.toJSON()),
      });
      if (!res.ok) throw new Error('save failed');
      setState('on');
      onNotice('Notifications on. You will get a ping when someone shares a reel 🔔');
    } catch {
      onNotice('Could not turn on notifications. Try again.');
    }
  }

  async function disable() {
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await fetch('/api/push/subscribe', {
          method: 'DELETE',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ endpoint: sub.endpoint }),
        });
        await sub.unsubscribe();
      }
      setState('off');
      onNotice('Notifications turned off.');
    } catch {
      onNotice('Could not turn off notifications.');
    }
  }

  if (state === 'loading') return null;

  if (state === 'unsupported')
    return (
      <button
        className="invite"
        onClick={() =>
          onNotice(
            'Notifications are not available here. On iPhone, tap Share → Add to Home Screen, then open loop. from the home screen.'
          )
        }
      >
        🔔 Notify me
      </button>
    );

  if (state === 'denied')
    return (
      <button
        className="invite"
        onClick={() => onNotice('Notifications are blocked. Allow them for this site in your browser settings.')}
      >
        🔕 Blocked
      </button>
    );

  return (
    <button className="invite" onClick={state === 'on' ? disable : enable}>
      {state === 'on' ? '🔔 Notifications on' : '🔔 Notify me'}
    </button>
  );
}
