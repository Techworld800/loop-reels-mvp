import webpush from 'web-push';
import { getSupabaseAdmin } from '@/lib/supabase';

type NewReel = { sharedBy: string; caption: string; excludeEndpoint?: string };

// Sends a push notification to every subscribed device (except the sender's own device).
export async function notifyNewReel({ sharedBy, caption, excludeEndpoint }: NewReel) {
  const pub = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || 'https://loop-reels-mvp.vercel.app';
  if (!pub || !priv) {
    console.error('[push] VAPID keys are missing; skipping notifications.');
    return;
  }
  const db = getSupabaseAdmin();
  if (!db) return;

  webpush.setVapidDetails(subject, pub, priv);

  const { data: subs, error } = await db
    .from('push_subscriptions')
    .select('endpoint,p256dh,auth')
    .limit(1000);
  if (error) {
    console.error('[push] could not load subscriptions', { code: error.code, message: error.message });
    return;
  }

  const payload = JSON.stringify({
    title: `${sharedBy} shared a new reel`,
    body: caption ? caption : 'Tap to watch it on loop.',
    url: '/',
  });

  const expired: string[] = [];
  await Promise.all(
    (subs || [])
      .filter((s) => s.endpoint !== excludeEndpoint)
      .map(async (s) => {
        try {
          await webpush.sendNotification(
            { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
            payload,
            { TTL: 60 * 60 * 24 }
          );
        } catch (err) {
          const status = (err as { statusCode?: number }).statusCode;
          if (status === 404 || status === 410) expired.push(s.endpoint);
          else console.error('[push] send failed', { status });
        }
      })
  );

  if (expired.length) await db.from('push_subscriptions').delete().in('endpoint', expired);
}
