import type { Metadata, Viewport } from 'next';
import './globals.css';
import SWRegister from './sw-register';
export const metadata: Metadata = { title: 'loop. — reels with your people', description: 'A private shared feed for your friends’ reels.', manifest: '/manifest.webmanifest', icons: { icon: [{ url: '/icon.svg', type: 'image/svg+xml' }, { url: '/icon-192.png', sizes: '192x192', type: 'image/png' }], apple: '/icon-192.png' } };
export const viewport: Viewport = { themeColor: '#f7f7f4' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body><SWRegister />{children}</body></html>; }
